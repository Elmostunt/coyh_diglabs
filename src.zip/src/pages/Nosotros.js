import React, { useEffect, useMemo, useState } from "react";
import { motion } from "framer-motion";

// --- util: scroll to top
const useScrollTop = () => {
  useEffect(() => {
    window.scrollTo({ top: 0, behavior: "smooth" });
  }, []);
};

// --- (opcional) logo si lo necesitas en otro lado
const Logo = ({ className = "max-w-[350px]" }) => (
  <img className={className} alt="Sur Digital Labs Logo" src="/logo.webp" />
);

// --- card de persona/mascota
const TeamCard = ({ name, role, img, linkedin, email, aria }) => (
  <div className="card group">
    <div
      className="w-full aspect-square card-image bg-center bg-cover rounded-xl"
      style={{ backgroundImage: `url(${img})` }}
      aria-label={aria || `Equipo Sur Digital Labs: ${name}`}
    />
    <div className="card-info mt-3 flex items-center justify-between">
      <div>
        <h2 className="font-semibold text-lg">{name}</h2>
        <p className="text-sm text-neutral-500">{role}</p>
      </div>
      <div className="flex items-center gap-2">
        {linkedin && (
          <a
            href={linkedin}
            target="_blank"
            rel="noopener noreferrer"
            className="link-card p-2 rounded hover:bg-neutral-100"
            aria-label={`${name} LinkedIn`}
          >
            <svg stroke="currentColor" fill="currentColor" viewBox="0 0 448 512" height="18" width="18" xmlns="http://www.w3.org/2000/svg"><path d="M100.28 448H7.4V148.9h92.88zM53.79 108.1C24.09 108.1 0 83.5 0 53.8a53.79 53.79 0 0 1 107.58 0c0 29.7-24.1 54.3-53.79 54.3zM447.9 448h-92.68V302.4c0-34.7-.7-79.2-48.29-79.2-48.29 0-55.69 37.7-55.69 76.7V448h-92.78V148.9h89.08v40.8h1.3c12.4-23.5 42.69-48.3 87.88-48.3 94 0 111.28 61.9 111.28 142.3V448z"></path></svg>
          </a>
        )}
        {email && (
          <a
            href={`mailto:${email}`}
            className="link-card p-2 rounded hover:bg-neutral-100"
            aria-label={`${name} email`}
          >
            <svg stroke="currentColor" fill="currentColor" viewBox="0 0 24 24" height="18" width="18" xmlns="http://www.w3.org/2000/svg"><path fill="none" d="M0 0h24v24H0V0z"></path><path d="M22 6c0-1.1-.9-2-2-2H4c-1.1 0-2 .9-2 2v12c0 1.1.9 2 2 2h16c1.1 0 2-.9 2-2V6zm-2 0-8 5-8-5h16zm0 12H4V8l8 5 8-5v10z"></path></svg>
          </a>
        )}
      </div>
    </div>
  </div>
);

// --- héroe / leyenda
const AboutHero = () => (
  <section className="md:m-0 md:mt-10 m-3 px-5">
    <div className="grid grid-cols-1 gap-12">
      <div className="flex flex-col gap-3">
        <motion.h1
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 1, type: "spring" }}
          className="text-3xl md:text-6xl pb-3 font-extrabold relative gradient-yellow uppercase text-center"
        >
          Sobre Sur Digital Labs
        </motion.h1>
      </div>

      <div className="flex lg:flex-row flex-col lg:gap-16 gap-8">
        <motion.div
          initial={{ opacity: 0, x: 20 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ delay: 0.4, duration: 1, type: "spring" }}
          className="flex flex-col gap-1"
        >
          <h2 className="text-xl font-bold uppercase">Nuestra Misión</h2>
          <div className="w-10 h-1 bg-black"></div>
          <p className="text-neutral-500 text-lg font-light mt-3">
            En <strong>Sur Digital Labs</strong> diseñamos y construimos soluciones
            de <em>software</em>, <em>datos</em> e <em>inteligencia artificial</em> que
            mejoran la vida de las personas y potencian a los negocios del sur de Chile y LATAM.
            Combinamos arquitectura de software y datos, <em>cloud</em> (GCP/AWS),
            y buenas prácticas de seguridad para entregar productos confiables,
            escalables y medibles.
          </p>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, x: 20 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ delay: 0.6, duration: 1, type: "spring" }}
          className="flex flex-col gap-1"
        >
          <h2 className="text-xl font-bold uppercase">Nuestra Historia</h2>
          <div className="w-10 h-1 bg-black"></div>
          <p className="text-neutral-500 text-lg font-light mt-3">
            Nacimos en <strong>Coyhaique, Aysén</strong>, con una idea simple:
            acercar tecnología de clase mundial a la Patagonia y a cualquier
            organización que valore la calidad técnica. Somos un estudio que une
            ingeniería, educación y comunidad: desarrollamos proyectos reales,
            formamos talento y aportamos al ecosistema con conocimiento abierto.
          </p>
        </motion.div>
      </div>
    </div>
  </section>
);

// --- sección equipo: solo Guillermo + Memo
const TeamSection = () => {
  const items = useMemo(
    () => [
      {
        name: "Guillermo Cárcamo Díaz",
        role: "Fundador & Arquitecto de Software y Datos",
        img: "/img/about/guillermo.jpg", // <-- reemplaza por tu ruta real
        // linkedin: "https://www.linkedin.com/in/tu-perfil", // opcional
        // email: "guillermo@tudominio.cl", // opcional
      },
      {
        name: "Memo",
        role: "Chief Happiness Officer (Feel Good Manager)",
        img: "/img/about/memo.webp", // <-- reemplaza por tu ruta real
      },
    ],
    []
  );

  return (
    <section className="lg:m-0 lg:mt-20 m-0 bg-neutral-100 py-20 px-5">
      <div className="container mx-auto pb-10 flex flex-col mt-10">
        <div className="flex flex-col items-center w-full relative">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: -5 }}
            viewport={{ once: true }}
            transition={{ delay: 0.6, duration: 1, type: "spring" }}
            className="gradient-yellow uppercase text-lg w-full text-center font-bold"
          >
            Nuestro equipo
          </motion.div>
          <motion.h1
            initial={{ opacity: 0, y: 10 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ delay: 0.9, duration: 1, type: "spring" }}
            className="text-3xl md:text-6xl pb-3 font-extrabold w-max relative text-neutral-800 uppercase"
          >
            ¿Quiénes somos?
          </motion.h1>
          <motion.div
            initial={{ width: 0 }}
            whileInView={{ width: "200px" }}
            viewport={{ once: true }}
            transition={{ delay: 1.1, duration: 1, type: "spring", bounce: 0.5 }}
            className="absolute w-32 h-1 bg-[var(--yellow)] bottom-[-0.7rem]"
          />
        </div>

        <motion.div
          initial={{ opacity: 0, y: 10 }}
          whileInView={{ opacity: 1, y: -10 }}
          viewport={{ once: true }}
          transition={{ delay: 1.3, duration: 1, type: "spring" }}
          className="text-neutral-600 text-lg text-center font-light mt-12 flex w-full justify-center"
        >
          <div className="max-w-screen-lg text-xl">
            Somos un laboratorio de soluciones tecnológicas desde la Patagonia:
            mezclamos ingeniería de software, analítica de datos y aprendizaje
            automático para resolver problemas concretos con impacto real.
          </div>
        </motion.div>

        <div className="relative">
          <div className="absolute top-[-100px] left-0 z-0 opacity-5 lg:block hidden">
            <img src="/img/hexagonal.png" className="rotate-anim w-[350px]" alt="decor" />
          </div>
        </div>

        <motion.div
          initial={{ opacity: 0, y: 10 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ delay: 0.3, duration: 1, type: "spring" }}
          className="grid md:grid-cols-2 grid-cols-1 mt-10 xl:px-32 px-0 z-10 gap-8"
        >
          {items.map((p, i) => (
            <TeamCard key={i} {...p} />
          ))}
        </motion.div>
      </div>
    </section>
  );
};

export default function Nosotros() {
  useScrollTop();
  return (
    <div className="min-h-screen bg-white text-neutral-900">
      <main>
        <div className="container mx-auto pb-10 flex flex-col gap-20">
          <AboutHero />
        </div>
        <TeamSection />
      </main>
      <div aria-live="assertive" aria-atomic="true" className="sr-only">
        Sobre Sur Digital Labs
      </div>
    </div>
  );
}

// pages/Footer.jsx
import React from 'react';
import './Footer.css';

const Footer = () => (
  <footer>
    <div className="h-max w-full bg-neutral-900 bg-dot-white/[0.2] relative flex items-center justify-center border-t-[10px] border-bg-azulOscuro">
      <div className="absolute opacity-50 pointer-events-none inset-0 flex items-center justify-center bg-azulOscuro [mask-image:radial-gradient(ellipse_at_center,transparent_20%,bg-azulOscuro)]" />
      <section className="py-32 px-6 md:px-8 w-full">
        <div className="md:grid md:grid-cols-4 flex flex-col gap-20 z-10 container mx-auto items-center justify-between">
          <div className="col-span-2 md:text-start text-center flex flex-col md:items-start items-center gap-5 text-white/90">
            <svg stroke="currentColor" fill="currentColor" viewBox="0 0 256 256" height="40" width="40" xmlns="http://www.w3.org/2000/svg"><path d="M222.72,67.91l-88-48.18a13.9,13.9,0,0,0-13.44,0l-88,48.18A14,14,0,0,0,26,80.18v95.64a14,14,0,0,0,7.28,12.27l88,48.18a13.92,13.92,0,0,0,13.44,0l88-48.18A14,14,0,0,0,230,175.82V80.18A14,14,0,0,0,222.72,67.91ZM218,175.82a2,2,0,0,1-1,1.75l-88,48.18a2,2,0,0,1-1.92,0L39,177.57a2,2,0,0,1-1-1.75V80.18a2,2,0,0,1,1-1.75l88-48.18a2,2,0,0,1,1.92,0l88,48.18a2,2,0,0,1,1,1.75Z"></path></svg>
            <p>
              Software is a tool that has recently emerged in human history, quickly becoming indispensable for most people. At SURLABS, we are fortunate to be experts in developing tools that, often behind the scenes, enable humans to advance in quality of life. Our mission is to improve the world with what we do best.
            </p>
            <div className="flex gap-5 items-center">
              <a
                href="https://www.linkedin.com/company/surlabssl/"
                className="text-white hover:text-[var(--yellow)] transition-all"
                target="_blank"
                rel="noopener noreferrer"
                aria-label="Surlabs on LinkedIn"
              >
                <svg stroke="currentColor" fill="currentColor" viewBox="0 0 448 512" height="25" width="25" xmlns="http://www.w3.org/2000/svg"><path d="M100.28 448H7.4V148.9h92.88zM53.79 108.1C24.09 108.1 0 83.5 0 53.8a53.79 53.79 0 0 1 107.58 0c0 29.7-24.1 54.3-53.79 54.3zM447.9 448h-92.68V302.4c0-34.7-.7-79.2-48.29-79.2-48.29 0-55.69 37.7-55.69 76.7V448h-92.78V148.9h89.08v40.8h1.3c12.4-23.5 42.69-48.3 87.88-48.3 94 0 111.28 61.9 111.28 142.3V448z"></path></svg>
                <span className="sr-only">Surlabs on LinkedIn</span>
              </a>
              <a
                href="https://twitter.com/surlabs#"
                rel="noopener noreferrer"
                className="text-white hover:text-[var(--yellow)] transition-all"
                target="_blank"
                aria-label="Surlabs on Twitter"
              >
                <svg stroke="currentColor" fill="currentColor" viewBox="0 0 512 512" height="25" width="25" xmlns="http://www.w3.org/2000/svg"><path d="M389.2 48h70.6L305.6 224.2 487 464H345L233.7 318.6 106.5 464H35.8L200.7 275.5 26.8 48H172.4L272.9 180.9 389.2 48zM364.4 421.8h39.1L151.1 88h-42L364.4 421.8z"></path></svg>
                <span className="sr-only">Surlabs on LinkedIn</span>
              </a>
            </div>
            <div className="text-neutral-400 text-sm">
              © 2025 Laboratorio de Soluciones del Sur S.L. All rights reserved.
            </div>
          </div>

          <div />

          <div className="flex flex-col text-start gap-3 mt-2 text-white/90">
            <a className="footer-link hover:text-[var(--yellow)]" href="/privacy">Privacy Policy</a>
            <a className="footer-link hover:text-[var(--yellow)]" href="/cookies">Cookies Policy</a>
            <a className="footer-link hover:text-[var(--yellow)]" href="/legal">Legal Notice</a>
          </div>
        </div>
      </section>
    </div>
  </footer>
);

export default Footer;


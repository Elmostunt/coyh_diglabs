import { useState } from "react"
import "./Empleos.css"

const Empleos = () => {
  const [sortBy, setSortBy] = useState("recent")

  const jobListings = [
    {
      id: 1,
      title: "Manager GenAI",
      department: "Data & AI",
      location: { country: "CHILE", city: "SANTIAGO" },
      timeAgo: "Hace3días",
    },
    {
      id: 2,
      title: "Data Platform Administrator",
      department: "Data & AI",
      location: { country: "CHILE", city: "SANTIAGO" },
      timeAgo: "Hace3días",
    },
    {
      id: 3,
      title: "Data Engineer Azure MLOps",
      department: "Data & AI",
      location: { country: "CHILE", city: "SANTIAGO" },
      timeAgo: "Hace3días",
    },
    {
      id: 4,
      title: "Especialista de Conectividad | Minería",
      department: "Information Technology Operations",
      location: { country: "CHILE", city: "SANTIAGO" },
      timeAgo: "Hace3días",
    },
    {
      id: 5,
      title: "Desarrollador/a iOS Senior",
      department: "Software Engineering",
      location: { country: "CHILE", city: "SANTIAGO" },
      timeAgo: "Hace3días",
    },
    {
      id: 6,
      title: "Consultores SAP Plant Maintenance",
      department: "Software Engineering",
      location: { country: "CHILE", city: "SANTIAGO" },
      timeAgo: "Hace3días",
    },
  ]

  return (
    <div className="empleos-container">
      <h1>Busca Oportunidades Laborales en Sur Digital Labs</h1>

      <div className="search-bar">
        <input type="text" placeholder="Usa comillas para coincidencia exacta" />
        <button>BUSCAR</button>
      </div>

      <div className="filters">
        <h2>Últimas búsquedas de Empleo (12)</h2>
        <div className="sort-options">
          <span>ORDENAR POR:</span>
          <button className={sortBy === "recent" ? "active" : ""} onClick={() => setSortBy("recent")}>
            MÁS RECIENTE
          </button>
          <span>|</span>
          <button className={sortBy === "relevant" ? "active" : ""} onClick={() => setSortBy("relevant")}>
            LO MÁS RELEVANTE
          </button>
        </div>
      </div>

      <div className="job-list">
        {jobListings.map((job) => (
          <div key={job.id} className="job-card">
            <div className="job-location">
              <span>{job.location.country}</span>
              <span>{job.location.city}</span>
            </div>
            <h3>{job.title}</h3>
            <p>{job.department}</p>
            <p className="time-ago">{job.timeAgo}</p>
          </div>
        ))}
      </div>
    </div>
  )
}

export default Empleos


import React from 'react';
import { Link } from 'react-router-dom';

const Home = () => {
  return (
    <div className="flex flex-col items-center justify-center min-h-screen bg-gray-100">
      <h1 className="text-4xl font-bold text-blue-600 mb-6">¡Bienvenido al Supermercado!</h1>
      <p className="text-lg text-gray-700 mb-8 text-center">
        Explora nuestros productos, gestiona tu carrito, revisa tus pedidos y administra usuarios.
      </p>
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <Link
          to="/productos"
          className="bg-blue-500 text-white py-4 px-6 rounded shadow-md hover:bg-blue-600 transition text-center"
        >
          Ver Productos
        </Link>
        <Link
          to="/carrito"
          className="bg-green-500 text-white py-4 px-6 rounded shadow-md hover:bg-green-600 transition text-center"
        >
          Ir al Carrito
        </Link>
        <Link
          to="/usuarios"
          className="bg-yellow-500 text-white py-4 px-6 rounded shadow-md hover:bg-yellow-600 transition text-center"
        >
          Ver Usuarios
        </Link>
        <Link
          to="/pedidos"
          className="bg-red-500 text-white py-4 px-6 rounded shadow-md hover:bg-red-600 transition text-center"
        >
          Revisar Pedidos
        </Link>
      </div>
    </div>
  );
};

export default Home;

import React, { useState, useEffect } from "react";

const bucketName = "surdigilabs_images";
const folderName = "carrusel";

// Pide también contentType y size para filtrar mejor
const apiUrl =
  `https://storage.googleapis.com/storage/v1/b/${bucketName}/o` +
  `?prefix=${folderName}/&fields=items(name,contentType,size)`;

// Utilidad: encodea cada segmento para soportar espacios/tildes
const encodeGcsPath = (name) =>
  name.split("/").map(encodeURIComponent).join("/");

const Home = () => {
  const [currentSlide, setCurrentSlide] = useState(0);
  const [slides, setSlides] = useState([]);

  useEffect(() => {
    const fetchImages = async () => {
      try {
        const res = await fetch(apiUrl);
        const data = await res.json();

        if (!data.items) return;

        // Filtra SOLO imágenes, sin “carpeta” y con tamaño > 0
        const archivos = data.items
          .filter(
            (it) =>
              it.name &&
              !it.name.endsWith("/") &&
              it.contentType?.startsWith("image/") &&
              Number(it.size) > 0
          )
          // Orden opcional por nombre para consistencia
          .sort((a, b) => a.name.localeCompare(b.name))
          .map((item) => {
            const path = encodeGcsPath(item.name);
            return {
              src: `https://storage.googleapis.com/${bucketName}/${path}`,
              alt: item.name.split("/").pop(),
            };
          });

        setSlides(archivos);
      } catch (error) {
        console.error("Error al obtener imágenes:", error);
      }
    };

    fetchImages();
  }, []);

  const showSlide = (index) => {
    setCurrentSlide((prev) => {
      const len = slides.length;
      if (len === 0) return prev;
      if (index >= len) return 0;
      if (index < 0) return len - 1;
      return index;
    });
  };

  const changeSlide = (direction) => showSlide(currentSlide + direction);

  // Autoplay
  useEffect(() => {
    if (slides.length === 0) return;
    const interval = setInterval(() => {
      setCurrentSlide((prev) => (prev + 1 >= slides.length ? 0 : prev + 1));
    }, 3000);
    return () => clearInterval(interval);
  }, [slides.length]);

  // Si una imagen falla (404, permisos, etc.), la removemos del carrusel
  const handleImgError = (idx) => {
    setSlides((prev) => prev.filter((_, i) => i !== idx));
    setCurrentSlide(0);
  };

  return (
    <div className="flex flex-col items-center justify-start w-full bg-blancoCremoso pt-20">
      {/* Carrusel */}
      <div className="relative w-full aspect-[16/9] max-h-[400px] overflow-hidden mt-[-80px]">
        {slides.length > 0 ? (
          slides.map((slide, index) => (
            <img
              key={index}
              src={slide.src}
              alt={slide.alt}
              onError={() => handleImgError(index)}
              className={`absolute inset-0 w-full h-full object-cover object-center transition-opacity duration-700 ${
                index === currentSlide ? "opacity-100" : "opacity-0"
              } pointer-events-none`}
              loading="eager"
              fetchPriority={index === currentSlide ? "high" : "auto"}
            />
          ))
        ) : (
          <p className="text-center text-gray-600">Cargando imágenes...</p>
        )}

        {/* Flechas */}
        <button
          onClick={() => changeSlide(-1)}
          className="absolute z-10 left-3 top-1/2 -translate-y-1/2 px-3 py-2 text-white font-bold text-lg rounded bg-black/45 hover:bg-black/70"
          aria-label="Anterior"
        >
          &#10094;
        </button>
        <button
          onClick={() => changeSlide(1)}
          className="absolute z-10 right-3 top-1/2 -translate-y-1/2 px-3 py-2 text-white font-bold text-lg rounded bg-black/45 hover:bg-black/70"
          aria-label="Siguiente"
        >
          &#10095;
        </button>
      </div>

      {/* Texto e interacción (igual que tenías) */}
      <h1 className="text-4xl font-bold text-azulOscuro mb-6 mt-6">
        ¡Bienvenido a Sur Digital Labs!
      </h1>
      <p className="text-lg text-azulGrisaceo mb-8 text-center">
        Explora nuestros Servicios, gestiona tu cita de consultoría y cotiza.
      </p>
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
        <a href="/servicios" className="bg-azulOscuro text-blancoHueso py-4 px-6 rounded shadow-md hover:bg-azulProfundo transition text-center font-semibold">Ver Servicios</a>
        <a href="/usuarios" className="bg-azulGrisaceo text-blancoHueso py-4 px-6 rounded shadow-md hover:bg-azulProfundo transition text-center font-semibold">Ver Usuarios</a>
        <a href="/pedidos" className="bg-blancoCremoso text-azulOscuro border border-azulOscuro py-4 px-6 rounded shadow-md hover:bg-azulOscuro hover:text-blancoHueso transition text-center font-semibold">Revisar Pedidos</a>
        <a href="/nosotros" className="bg-azulOscuro text-blancoHueso py-4 px-6 rounded shadow-md hover:bg-azulProfundo transition text-center font-semibold">Nosotros</a>
        <a href="/empleos" className="bg-azulGrisaceo text-blancoHueso py-4 px-6 rounded shadow-md hover:bg-azulProfundo transition text-center font-semibold">Empleos</a>
      </div>
    </div>
  );
};

export default Home;
